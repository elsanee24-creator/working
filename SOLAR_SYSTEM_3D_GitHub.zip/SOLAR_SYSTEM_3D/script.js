import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/jsm/controls/OrbitControls.js';

const mount = document.querySelector('#scene');
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x030611);
scene.fog = new THREE.FogExp2(0x030611, 0.0017);
const camera = new THREE.PerspectiveCamera(48, innerWidth / innerHeight, 0.1, 1800);
camera.position.set(0, 95, 185);
const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.setSize(innerWidth, innerHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.18;
mount.appendChild(renderer.domElement);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true; controls.dampingFactor = 0.045;
controls.minDistance = 24; controls.maxDistance = 420;
controls.maxPolarAngle = Math.PI * 0.88;
scene.add(new THREE.AmbientLight(0x8a9ab8, 0.45));
const sunLight = new THREE.PointLight(0xffd7a0, 3.8, 700, 1.25);
scene.add(sunLight);

const textureLoader = new THREE.TextureLoader();
const raycaster = new THREE.Raycaster();
const pointer = new THREE.Vector2();
const clickable = [];
const planetObjects = [];
let selected = null, paused = false, speed = 1;
const clock = new THREE.Clock();

function makeCanvasTexture(kind, base, colors) {
  const c = document.createElement('canvas'); c.width = 1024; c.height = 512;
  const ctx = c.getContext('2d');
  ctx.fillStyle = base; ctx.fillRect(0,0,c.width,c.height);
  if (kind === 'bands') {
    for(let y=0;y<512;y++){ const wave=Math.sin(y*.055)*10+Math.sin(y*.013)*15; ctx.fillStyle=colors[Math.floor((y+wave)/25)%colors.length]; ctx.globalAlpha=.75; ctx.fillRect(0,y,1024,Math.max(2,16+Math.sin(y*.08)*9)); }
    ctx.globalAlpha=1;
    for(let i=0;i<90;i++){ctx.fillStyle=colors[i%colors.length];ctx.globalAlpha=.12;ctx.beginPath();ctx.ellipse(Math.random()*1024,Math.random()*512,20+Math.random()*100,2+Math.random()*9,0,0,Math.PI*2);ctx.fill()}
  } else if(kind === 'cloud') {
    for(let i=0;i<9000;i++){ctx.fillStyle=colors[Math.floor(Math.random()*colors.length)];ctx.globalAlpha=.12+Math.random()*.22;ctx.beginPath();ctx.ellipse(Math.random()*1024,Math.random()*512,2+Math.random()*38,1+Math.random()*8,0,0,Math.PI*2);ctx.fill()}
  } else {
    for(let i=0;i<18000;i++){ctx.fillStyle=colors[Math.floor(Math.random()*colors.length)];ctx.globalAlpha=Math.random()*.4;ctx.fillRect(Math.random()*1024,Math.random()*512,1+Math.random()*5,1+Math.random()*2)}
    for(let i=0;i<220;i++){ctx.fillStyle=colors[i%colors.length];ctx.globalAlpha=.12;ctx.beginPath();ctx.arc(Math.random()*1024,Math.random()*512,2+Math.random()*12,0,Math.PI*2);ctx.fill()}
  }
  const tex = new THREE.CanvasTexture(c); tex.colorSpace=THREE.SRGBColorSpace; tex.anisotropy=8; return tex;
}

const data = [
 {name:'Mercury',type:'TERRESTRIAL PLANET',radius:1.35,distance:13,speed:.95,rotation:.004,color:'#9b938b',texture:['#77716b','#c0b5a6','#e0d6c8'],diameter:'4,879 km',orbit:'88 Earth days',day:'58.6 Earth days',desc:'A small, rocky world with a heavily cratered surface and extreme temperature changes.',kind:'rock'},
 {name:'Venus',type:'TERRESTRIAL PLANET',radius:2.25,distance:20,speed:.72,rotation:-.001,color:'#d5a76e',texture:['#a76d3d','#e4c18a','#f5dca7'],diameter:'12,104 km',orbit:'225 Earth days',day:'243 Earth days',desc:'A bright world wrapped in thick clouds and an exceptionally hot atmosphere.',kind:'cloud'},
 {name:'Earth',type:'TERRESTRIAL PLANET',radius:2.45,distance:29,speed:.58,rotation:.018,color:'#3b91d2',texture:['#124e91','#238b55','#b9d5e8'],diameter:'12,742 km',orbit:'365.25 days',day:'23 h 56 min',desc:'Our home planet, with liquid-water oceans, continents and a protective atmosphere.',kind:'earth'},
 {name:'Mars',type:'TERRESTRIAL PLANET',radius:1.85,distance:39,speed:.46,rotation:.015,color:'#c66c4b',texture:['#7e3021','#c56a45','#e3a17b'],diameter:'6,779 km',orbit:'687 Earth days',day:'24 h 37 min',desc:'A cold desert world with rusty terrain, giant volcanoes and ancient river valleys.',kind:'rock'},
 {name:'Jupiter',type:'GAS GIANT',radius:7.3,distance:61,speed:.25,rotation:.035,color:'#d4a77f',texture:['#9b6547','#d7b38f','#f0d9bb','#b67d5b'],diameter:'139,820 km',orbit:'11.86 Earth years',day:'9 h 56 min',desc:'The largest planet, famous for its striped cloud belts and the Great Red Spot.',kind:'bands'},
 {name:'Saturn',type:'GAS GIANT',radius:6.2,distance:85,speed:.17,rotation:.03,color:'#d7bd8a',texture:['#9f815c','#d8c39a','#f1dfb8'],diameter:'116,460 km',orbit:'29.4 Earth years',day:'10 h 42 min',desc:'A gas giant surrounded by an immense, bright system of icy rings.',kind:'bands',rings:true},
 {name:'Uranus',type:'ICE GIANT',radius:4.1,distance:108,speed:.12,rotation:-.022,color:'#8bd4d8',texture:['#66aeb8','#a6e0df','#d3f4eb'],diameter:'50,724 km',orbit:'84 Earth years',day:'17 h 14 min',desc:'A pale blue ice giant that rotates on its side, giving it unusual seasons.',kind:'cloud'},
 {name:'Neptune',type:'ICE GIANT',radius:4.0,distance:130,speed:.09,rotation:.02,color:'#426fe0',texture:['#173a9a','#356bd6','#75a8ed'],diameter:'49,244 km',orbit:'164.8 Earth years',day:'16 h 6 min',desc:'A distant, deep-blue world with powerful winds and dynamic weather.',kind:'cloud'}
];

function addStars() {
 const positions=[]; for(let i=0;i<6500;i++){const r=THREE.MathUtils.randFloat(230,850), t=Math.random()*Math.PI*2, p=Math.acos(THREE.MathUtils.randFloatSpread(2));positions.push(r*Math.sin(p)*Math.cos(t),r*Math.cos(p),r*Math.sin(p)*Math.sin(t))}
 const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));
 const mat=new THREE.PointsMaterial({color:0xc9dcff,size:.75,sizeAttenuation:true,transparent:true,opacity:.85});
 scene.add(new THREE.Points(geo,mat));
}
addStars();

const sunGeo=new THREE.SphereGeometry(8.5,80,64);
const sunMat=new THREE.MeshBasicMaterial({map:makeCanvasTexture('cloud','#f18b25',['#ffb13b','#ffd16b','#f36d1d','#fff0a3','#c84c18'])});
const sun=new THREE.Mesh(sunGeo,sunMat);scene.add(sun);clickable.push(sun);
const glow=new THREE.Sprite(new THREE.SpriteMaterial({map:(()=>{const c=document.createElement('canvas');c.width=c.height=256;const x=c.getContext('2d'),g=x.createRadialGradient(128,128,5,128,128,128);g.addColorStop(0,'rgba(255,196,105,.55)');g.addColorStop(.3,'rgba(255,125,40,.18)');g.addColorStop(1,'rgba(255,100,20,0)');x.fillStyle=g;x.fillRect(0,0,256,256);return new THREE.CanvasTexture(c)})(),transparent:true,depthWrite:false}));
glow.scale.set(46,46,1);sun.add(glow);

const sunCorona=new THREE.Mesh(new THREE.SphereGeometry(9.1,48,32),new THREE.MeshBasicMaterial({color:0xff9c38,transparent:true,opacity:.11,side:THREE.BackSide}));sun.add(sunCorona);

const orbitGroups=[];
data.forEach((d,i)=>{
 const orbit=new THREE.Group();scene.add(orbit);orbitGroups.push(orbit);
 const ring=new THREE.Mesh(new THREE.RingGeometry(d.distance-.055,d.distance+.055,220),new THREE.MeshBasicMaterial({color:0x8293ae,transparent:true,opacity:.25,side:THREE.DoubleSide}));
 ring.rotation.x=-Math.PI/2;scene.add(ring);
 const group=new THREE.Group();orbit.add(group);
 const texture=makeCanvasTexture(d.kind,d.color,d.texture);
 const material=new THREE.MeshStandardMaterial({map:texture,roughness:d.name==='Earth'?.82:.94,metalness:0});
 const mesh=new THREE.Mesh(new THREE.SphereGeometry(d.radius,64,48),material);
 mesh.position.x=d.distance;mesh.rotation.z=d.name==='Uranus'?Math.PI/2:0;group.add(mesh);
 mesh.userData.planet=d;clickable.push(mesh);planetObjects.push({mesh,group,orbit,data:d});
 if(d.rings){
   const ringGeo=new THREE.RingGeometry(d.radius*1.28,d.radius*2.15,128);
   const pos=ringGeo.attributes.position;const uv=ringGeo.attributes.uv;
   const ringMat=new THREE.MeshStandardMaterial({color:0xc9b58f,roughness:1,metalness:0,side:THREE.DoubleSide,transparent:true,opacity:.82});
   const saturnRing=new THREE.Mesh(ringGeo,ringMat);saturnRing.rotation.x=-Math.PI/2.35;saturnRing.rotation.y=.12;saturnRing.position.copy(mesh.position);group.add(saturnRing);
   const inner=new THREE.Mesh(new THREE.RingGeometry(d.radius*1.18,d.radius*1.27,128),new THREE.MeshBasicMaterial({color:0x76624c,side:THREE.DoubleSide,transparent:true,opacity:.7}));inner.rotation.copy(saturnRing.rotation);inner.position.copy(mesh.position);group.add(inner);
 }
 if(d.name==='Earth'){
   const cloud=new THREE.Mesh(new THREE.SphereGeometry(d.radius*1.018,48,32),new THREE.MeshStandardMaterial({map:makeCanvasTexture('cloud','#ffffff',['#ffffff','#d8f5ff','#a9d4e8']),transparent:true,opacity:.2,roughness:1}));
   cloud.position.copy(mesh.position);group.add(cloud);mesh.userData.cloud=cloud;
   const moonPivot=new THREE.Group();moonPivot.position.x=d.distance;group.add(moonPivot);
   const moon=new THREE.Mesh(new THREE.SphereGeometry(.68,32,24),new THREE.MeshStandardMaterial({map:makeCanvasTexture('rock','#88847e',['#5d5a56','#c5c0b7','#e1ddd4']),roughness:1}));
   moon.position.set(7,0,0);moonPivot.add(moon);mesh.userData.moonPivot=moonPivot;
 }
});

function addAsteroids(){
 const count=1600, geo=new THREE.IcosahedronGeometry(.22,0), mat=new THREE.MeshStandardMaterial({color:0x8b8174,roughness:1});
 const inst=new THREE.InstancedMesh(geo,mat,count);const dummy=new THREE.Object3D();
 for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,r=46+Math.random()*8,y=(Math.random()-.5)*2.5;dummy.position.set(Math.cos(a)*r,y,Math.sin(a)*r);const s=.25+Math.random()*1.5;dummy.scale.set(s,s*(.5+Math.random()),s);dummy.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3);dummy.updateMatrix();inst.setMatrixAt(i,dummy.matrix)}
 scene.add(inst);
}
addAsteroids();

const info=document.querySelector('#infoPanel');
function selectObject(obj){
 selected=obj;
 const d=obj===sun?null:obj.userData.planet;
 document.querySelector('#planetType').textContent=d?d.type:'STAR';
 document.querySelector('#planetName').textContent=d?d.name:'The Sun';
 document.querySelector('#planetDesc').textContent=d?d.desc:'The star at the centre of our solar system, providing the light and energy that make life on Earth possible.';
 document.querySelector('#planetDiameter').textContent=d?d.diameter:'1.39 million km';
 document.querySelector('#planetOrbit').textContent=d?d.orbit:'Centre';
 document.querySelector('#planetDay').textContent=d?d.day:'~25 Earth days';
 document.querySelectorAll('.planet-chip').forEach(b=>b.classList.toggle('active',b.dataset.name===(d?d.name:'The Sun')));
 info.classList.remove('hidden');
}
function focusSelected(){
 if(!selected)return;
 const target=new THREE.Vector3();selected.getWorldPosition(target);
 const offset=new THREE.Vector3(0,selected===sun?25:Math.max(12,selected.geometry.parameters.radius*3.5),selected===sun?42:Math.max(18,selected.geometry.parameters.radius*5));
 controls.target.copy(target);camera.position.copy(target).add(offset);controls.update();
}
selectObject(sun);
const list=document.querySelector('#planetList');
['The Sun',...data.map(d=>d.name)].forEach(name=>{const b=document.createElement('button');b.className='planet-chip';b.textContent=name;b.dataset.name=name;b.addEventListener('click',()=>{const obj=name==='The Sun'?sun:planetObjects.find(p=>p.data.name===name).mesh;selectObject(obj);focusSelected()});list.appendChild(b)});
renderer.domElement.addEventListener('pointerdown',e=>{pointer.x=(e.clientX/innerWidth)*2-1;pointer.y=-(e.clientY/innerHeight)*2+1;raycaster.setFromCamera(pointer,camera);const hit=raycaster.intersectObjects(clickable,false)[0];if(hit){selectObject(hit.object);focusSelected()}});
document.querySelector('#closeInfo').addEventListener('click',()=>info.classList.add('hidden'));
document.querySelector('#focusBtn').addEventListener('click',focusSelected);
document.querySelector('#pauseBtn').addEventListener('click',e=>{paused=!paused;e.currentTarget.innerHTML=paused?'▶ <span>PLAY</span>':'Ⅱ <span>PAUSE</span>';document.querySelector('#statusText').textContent=paused?'SIMULATION PAUSED':'SYSTEM RUNNING'});
document.querySelector('#resetBtn').addEventListener('click',()=>{camera.position.set(0,95,185);controls.target.set(0,0,0);controls.update();selectObject(sun)});
document.querySelector('#speed').addEventListener('input',e=>{speed=Number(e.target.value);document.querySelector('#speedValue').textContent=speed.toFixed(1)+'×'});

function animate(){
 requestAnimationFrame(animate);
 const delta=Math.min(clock.getDelta(),.04);
 if(!paused){
   sun.rotation.y+=delta*.035*speed;
   planetObjects.forEach(({mesh,group,orbit,data})=>{
     orbit.rotation.y+=delta*data.speed*.12*speed;
     mesh.rotation.y+=delta*data.rotation*18*speed;
     if(mesh.userData.cloud)mesh.userData.cloud.rotation.y+=delta*.003*speed;
     if(mesh.userData.moonPivot)mesh.userData.moonPivot.rotation.y+=delta*.42*speed;
   });
 }
 controls.update();renderer.render(scene,camera);
}
animate();
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,2))});
